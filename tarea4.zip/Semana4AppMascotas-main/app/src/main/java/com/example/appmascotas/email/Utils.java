package com.example.appmascotas.email;

public class Utils {

    public static final String EMAIL = "Masctoas@gmail.com";

    public static final String PASSWORD = "123123123123";
}
