package com.example.appmascotas;

public interface Favoritos {
}
